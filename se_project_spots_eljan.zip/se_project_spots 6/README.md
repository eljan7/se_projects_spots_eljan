Spots is a simple, responsive personal profile webpage built with HTML, CSS, and JavaScript.
It allows a user to edit their profile information and add new photo posts through accessible modal dialogs.

This project demonstrates core front-end skills, semantic markup, accessibility practices, and responsive UI design.

Features
✔ Profile Section

Displays avatar, name, and brief description

“Edit Profile” button opens a modal to update text fields

Uses semantic HTML elements for clear structure

✔ Photo Cards

Grid of images with titles

Each card contains a like button (aria-label applied for accessibility)

Images include descriptive alt text

✔ Accessible Modals

Two modals: Edit Profile and New Post

Keyboard and screen-reader friendly:

aria-modal="true"

role="dialog"

aria-labelledby for dialog titles

Close buttons have proper aria-label

Smooth open/close animation

Mobile-optimized layout with a dedicated media query

✔ Responsive Layout

Fully responsive using flexible CSS layout and mobile breakpoints

Modal content adjusts padding, font sizes, and button width on small screens

Tech Stack

HTML5

CSS3

BEM naming conventions

Custom modal component

Media queries for mobile resolution

JavaScript (Vanilla)

Handles modal open/close

Dynamically updates profile information

Creates new cards from form input

Project Structure
project/
│
├── index.html
├── pages/
│   └── index.css
├── scripts/
│   └── index.js
├── images/
│   ├── avatar.jpg
│   ├── logo.svg
│   ├── plus.svg
│   ├── pencil.svg
│   └── ...photo assets
└── favicon.ico


🧾 Author Eljan