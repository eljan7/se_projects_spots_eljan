const initialCards = [
  {
    name: "Golden Gate Bridge",
    link: "https://practicum-content.s3.us-west-1.amazonaws.com/software-engineer/spots/7-photo-by-griffin-wooldridge-from-pexels.jpg",
  },
  {
    name: "Val Thorens",
    link: "https://practicum-content.s3.us-west-1.amazonaws.com/software-engineer/spots/1-photo-by-moritz-feldmann-from-pexels.jpg",
  },
  {
    name: "Restaurant terrace",
    link: "https://practicum-content.s3.us-west-1.amazonaws.com/software-engineer/spots/2-photo-by-celine-from-pexels.jpg",
  },
  {
    name: "An outdoor cafe",
    link: "https://practicum-content.s3.us-west-1.amazonaws.com/software-engineer/spots/3-photo-by-tubanur-dogan-from-pexels.jpg",
  },
  {
    name: "A very long bridge, over the forest and through the trees",
    link: "https://practicum-content.s3.us-west-1.amazonaws.com/software-engineer/spots/4-photo-by-maurice-laschet-from-pexels.jpg",
  },
  {
    name: "Tunnel with morning light",
    link: "https://practicum-content.s3.us-west-1.amazonaws.com/software-engineer/spots/5-photo-by-van-anh-nguyen-from-pexels.jpg",
  },
  {
    name: "Mountain house",
    link: "https://practicum-content.s3.us-west-1.amazonaws.com/software-engineer/spots/6-photo-by-moritz-feldmann-from-pexels.jpg",
  },
];

// ===== DOM =====
const cardsList = document.querySelector(".cards__list");

// template
const cardTemplate = document.querySelector("#card-template");

// profile edit modal
const editProfileBtn = document.querySelector(".profile__edit-btn");
const editProfileModal = document.querySelector("#edit-profile-modal");
const editProfileCloseBtn = editProfileModal.querySelector(".modal__close-button");
const editProfileForm = editProfileModal.querySelector("#profile-form");
const editProfileNameInput = editProfileModal.querySelector("#profile-name-input");
const editProfileDescriptionInput = editProfileModal.querySelector(
  "#profile-description-input"
);

const profileNameElement = document.querySelector(".profile__name");
const profileDescriptionElement = document.querySelector(".profile__description");

// new post modal
const newPostBtn = document.querySelector(".profile__add-btn");
const newPostModal = document.querySelector("#new-post-modal");
const newPostCloseBtn = newPostModal.querySelector(".modal__close-button");
const newPostForm = newPostModal.querySelector("#new-post-form");
const newPostImageInput = newPostModal.querySelector("#card-image-input");
const newPostCaptionInput = newPostModal.querySelector("#card-caption-input");

// preview modal
const previewModal = document.querySelector("#preview-modal");
const previewModalCloseBtn = previewModal.querySelector(".modal__close");
const previewImageElement = previewModal.querySelector(".modal__image");
const previewCaptionElement = previewModal.querySelector(".modal__caption");

// ===== Cards =====
function getCardElement(data) {
  // make a clone of the card element
  const cardElement = cardTemplate.content.querySelector(".card").cloneNode(true);

  // select the card element's title and image
  const cardTitle = cardElement.querySelector(".card__title");
  const cardImage = cardElement.querySelector(".card__image");

  // assign values from data
  cardImage.src = data.link;
  cardImage.alt = data.name;
  cardTitle.textContent = data.name;

  // like button
  const likeButton = cardElement.querySelector(".card__like-btn");
  likeButton.addEventListener("click", () => {
    likeButton.classList.toggle("card__like-btn_active");
  });

  // delete button
  const deleteButton = cardElement.querySelector(".card__delete-btn");
  deleteButton.addEventListener("click", () => {
    cardElement.remove();
  });

  // preview modal on image click
  cardImage.addEventListener("click", () => {
    previewCaptionElement.textContent = data.name;
    previewImageElement.src = data.link;
    previewImageElement.alt = data.name;
    openModal(previewModal);
  });

  return cardElement;
}

function renderInitialCards() {
  // prepend each created card into the list, while keeping array order
  [...initialCards].reverse().forEach((cardData) => {
    const cardElement = getCardElement(cardData);
    cardsList.prepend(cardElement);
  });
}

// ===== Modals =====
let openedModal = null;

function handleEscapeKey(evt) {
  if (evt.key === "Escape" && openedModal) {
    closeModal(openedModal);
  }
}

function openModal(modal) {
  openedModal = modal;
  modal.classList.add("modal_is-opened");
  document.addEventListener("keydown", handleEscapeKey);
}

function closeModal(modal) {
  modal.classList.remove("modal_is-opened");
  openedModal = null;
  document.removeEventListener("keydown", handleEscapeKey);
}

function setModalListeners(modal) {
  modal.addEventListener("mousedown", (evt) => {
    // close on overlay click (not on the modal content)
    if (evt.target === modal) {
      closeModal(modal);
    }
  });
}

setModalListeners(editProfileModal);
setModalListeners(newPostModal);
setModalListeners(previewModal);

// ===== Edit Profile =====
editProfileBtn.addEventListener("click", () => {
  editProfileNameInput.value = profileNameElement.textContent;
  editProfileDescriptionInput.value = profileDescriptionElement.textContent;
  openModal(editProfileModal);
});

editProfileCloseBtn.addEventListener("click", () => closeModal(editProfileModal));

editProfileForm.addEventListener("submit", (evt) => {
  evt.preventDefault();
  profileNameElement.textContent = editProfileNameInput.value.trim();
  profileDescriptionElement.textContent = editProfileDescriptionInput.value.trim();
  closeModal(editProfileModal);
});

// ===== New Post =====
newPostBtn.addEventListener("click", () => openModal(newPostModal));
newPostCloseBtn.addEventListener("click", () => closeModal(newPostModal));

newPostForm.addEventListener("submit", (evt) => {
  evt.preventDefault();

  const newCardData = {
    name: newPostCaptionInput.value.trim(),
    link: newPostImageInput.value.trim(),
  };

  const newCardElement = getCardElement(newCardData);
  cardsList.prepend(newCardElement);

  newPostForm.reset();
  closeModal(newPostModal);
});

// ===== Preview modal close =====
previewModalCloseBtn.addEventListener("click", () => closeModal(previewModal));

// init
renderInitialCards();
